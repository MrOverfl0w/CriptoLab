package org.bouncycastle.asn1;

/**
 * @deprecated use BERTags
 */
public interface DERTags
    extends BERTags
{
}
