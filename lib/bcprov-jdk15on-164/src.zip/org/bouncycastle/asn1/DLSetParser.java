package org.bouncycastle.asn1;

/**
 * Parser class for DL SETs.
 */
public class DLSetParser extends DERSetParser
{
    DLSetParser(ASN1StreamParser parser)
    {
        super(parser);
    }
}
